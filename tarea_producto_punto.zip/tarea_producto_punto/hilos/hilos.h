#ifndef HILOS_H
#define HILOS_H

#include "defs.h"

void *funHilo(void *arg);


#endif