#ifndef HELPER_H
#define HELPER_H

int *reservarMemoria(void);
void llenarArreglo(int datos[]);
void imprimirArreglo(int datos[]);

#endif