#ifndef DEFS_H
#define DEFS_H

#define NUM_PROC 4
#define N 4096

#endif